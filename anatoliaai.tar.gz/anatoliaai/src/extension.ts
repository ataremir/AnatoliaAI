import * as vscode from 'vscode';
import { ChatPanel } from './chatPanel';

export function activate(context: vscode.ExtensionContext) {
    const chatProvider = new ChatPanel(context.extensionUri, context);
    context.subscriptions.push(
        vscode.window.registerWebviewViewProvider(ChatPanel.viewType, chatProvider),
        vscode.commands.registerCommand('anatoliaai.terminalAc', () => {
            const terminal = vscode.window.createTerminal('Anatolia Terminal');
            terminal.show();
            terminal.sendText("echo 'AnatoliaAI Terminali Hazir!'");
        }),
        vscode.commands.registerCommand('anatoliaai.dosyaAc', async () => {
            if (!vscode.workspace.workspaceFolders) {
                vscode.window.showErrorMessage('Önce bir proje klasörü açmalısın.');
                return;
            }
            const yol = vscode.workspace.workspaceFolders[0].uri.fsPath + '/yeni_script.py';
            await vscode.workspace.fs.writeFile(vscode.Uri.file(yol), Buffer.from("# AnatoliaAI\nprint('Merhaba')", 'utf8'));
            vscode.window.showInformationMessage('Dosya oluşturuldu!');
        }),
        vscode.commands.registerCommand('anatoliaai.klasorAc', async () => {
            if (!vscode.workspace.workspaceFolders) {
                vscode.window.showErrorMessage('Önce bir proje klasörü açmalısın.');
                return;
            }
            const yol = vscode.workspace.workspaceFolders[0].uri.fsPath + '/Anatolia_Klasor';
            await vscode.workspace.fs.createDirectory(vscode.Uri.file(yol));
            vscode.window.showInformationMessage('Klasör oluşturuldu!');
        }),
        vscode.commands.registerCommand('anatoliaai.aiKomut', async () => {
            const komut = await vscode.window.showInputBox({
                placeHolder: 'Örnek: Bana Python dosyası aç',
                prompt: 'AnatoliaAI - Ne yapmamı istersin?'
            });
            if (!komut) return;
            const k = komut.toLowerCase();
            if (k.includes('terminal') || k.includes('konsol')) {
                vscode.commands.executeCommand('anatoliaai.terminalAc');
                vscode.window.showInformationMessage('✅ Terminal açılıyor...');
            } else if (k.includes('dosya') || k.includes('file') || k.includes('python')) {
                vscode.commands.executeCommand('anatoliaai.dosyaAc');
                vscode.window.showInformationMessage('✅ Dosya oluşturuluyor...');
            } else if (k.includes('klasör') || k.includes('klasor') || k.includes('folder')) {
                vscode.commands.executeCommand('anatoliaai.klasorAc');
                vscode.window.showInformationMessage('✅ Klasör oluşturuluyor...');
            } else {
                vscode.window.showWarningMessage('❌ Komutu anlayamadım.');
            }
        })
    );
}

export function deactivate() {}
