/**
 * ============================================================
 * AnatoliaAI Chat Panel - Ana Dosya
 * 
 * Bu dosya VSCode extension'ı için chat panelini yönetir.
 * Aşağıdaki özellikleri içerir:
 * - Gemini AI entegrasyonu
 * - Terminal komut onay mekanizması
 * - Güvenli mesajlaşma sistemi
 * 
 * @author AnatoliaAI
 * @version 2.0.0
 * ============================================================
 */

// ============================================================
// Module Imports - Gerekli kütüphanelerin import edilmesi
// ============================================================

import * as vscode from 'vscode';
import { GoogleGenerativeAI } from '@google/generative-ai';

// ============================================================
// Type Definitions - TypeScript tip tanımlamaları
// ============================================================

/**
 * Desteklenen model sağlayıcıları
 */
type ModelProvider = 'gemini' | 'huggingface' | 'groq';

/**
 * Webview'den gelen mesaj tipleri
 * Her mesaj tipi farklı bir eylemi temsil eder
 */
interface WebviewMessage {
    type: 'userMessage' | 'runCommand' | 'apiKeyChange' | 'quickAction' | 'modelChange' | 'copyCode' | 'requestConfirmation' | 'confirmCommand' | 'cancelCommand';
    [key: string]: any;
}

/**
 * Kullanıcı mesajı veri tipi
 */
interface UserMessageData {
    type: 'userMessage';
    text: string;
}

/**
 * Komut çalıştırma veri tipi
 */
interface RunCommandData {
    type: 'runCommand';
    command: string;
}

/**
 * API anahtarı değişikliği veri tipi
 */
interface ApiKeyChangeData {
    type: 'apiKeyChange';
    model: string;
    key: string;
}

/**
 * Hızlı eylem veri tipi
 */
interface QuickActionData {
    type: 'quickAction';
    action: string;
}

/**
 * Model değişikliği veri tipi
 */
interface ModelChangeData {
    type: 'modelChange';
    model: string;
}

/**
 * Kod kopyalama veri tipi
 */
interface CopyCodeData {
    type: 'copyCode';
    code: string;
}

/**
 * Komut onayı isteme veri tipi
 * Kullanıcıdan terminal komutu onayı ister
 */
interface RequestConfirmationData {
    type: 'requestConfirmation';
    command: string;
    action: string;
}

/**
 * Komut onaylama veri tipi
 */
interface ConfirmCommandData {
    type: 'confirmCommand';
    command: string;
}

/**
 * Komut iptal etme veri tipi
 */
interface CancelCommandData {
    type: 'cancelCommand';
    command: string;
}

/**
 * Gelen mesajların birleşik tipi
 * Union type kullanarak tüm mesaj tiplerini birleştirir
 */
type IncomingMessage = 
    | UserMessageData 
    | RunCommandData 
    | ApiKeyChangeData 
    | QuickActionData 
    | ModelChangeData 
    | CopyCodeData 
    | RequestConfirmationData 
    | ConfirmCommandData 
    | CancelCommandData;

// ============================================================
// ChatPanel Class - Ana sınıf tanımı
// ============================================================

/**
 * ChatPanel sınıfı
 * VSCode webview panelini yönetir ve AI ile iletişimi sağlar
 */
export class ChatPanel implements vscode.WebviewViewProvider {
    
    // -------------------------------------------------------
    // Public Properties - Herkese açık özellikler
    // -------------------------------------------------------
    
    /** Webview görünüm tipi */
    public static readonly viewType = 'anatoliaai-chat';
    
    // -------------------------------------------------------
    // Private Properties - Özel özellikler
    // -------------------------------------------------------
    
    /** Webview görünüm nesnesi */
    private _view?: vscode.WebviewView;
    
    /** Google Generative AI nesnesi */
    private _geminiApi?: GoogleGenerativeAI;
    
    /** API anahtarları haritası */
    private _apiKeys: Map<ModelProvider, string> = new Map();

    // ============================================================
    // Constructor - Yapıcı metot
    // ============================================================

    /**
     * ChatPanel yapıcı metodu
     * Extension URI ve context bilgilerini alır
     * 
     * @param _extensionUri - Extension'in URI bilgisi
     * @param _context - Extension context bilgisi
     */
    constructor(
        private readonly _extensionUri: vscode.Uri,
        private readonly _context: vscode.ExtensionContext
    ) {
        // Yapıcı metodunda API anahtarlarını yükle
        this._loadApiKeys();
    }

    // ============================================================
    // Private Methods - Özel metotlar
    // ============================================================

    /**
     * API anahtarlarını güvenli depolamadan yükler
     * Extension başladığında çağrılır
     */
    private async _loadApiKeys(): Promise<void> {
        // Gemini API anahtarını yükle
        const geminiKey = await this._context.secrets.get('gemini_key');
        if (geminiKey) {
            this._geminiApi = new GoogleGenerativeAI(geminiKey);
            this._apiKeys.set('gemini', geminiKey);
        }
        
        // Hugging Face API anahtarını yükle
        const hfKey = await this._context.secrets.get('huggingface_key');
        if (hfKey) {
            this._apiKeys.set('huggingface', hfKey);
        }
        
        // Groq API anahtarını yükle
        const groqKey = await this._context.secrets.get('groq_key');
        if (groqKey) {
            this._apiKeys.set('groq', groqKey);
        }
    }

    /**
     * Webview görünümünü çözümler
     * Bu metot VSCode tarafından webview her açıldığında çağrılır
     * 
     * @param webviewView - Webview görünüm nesnesi
     */
    public resolveWebviewView(webviewView: vscode.WebviewView): void {
        // Webview nesnesini sakla
        this._view = webviewView;
        
        // Webview seçeneklerini yapılandır
        webviewView.webview.options = {
            enableScripts: true,
            localResourceRoots: [this._extensionUri]
        };

        // Webview HTML içeriğini ayarla
        webviewView.webview.html = this._getHtmlForWebview();

        // ============================================================
        // ÖNEMLİ: TS18046 Tip Hatası Çözümü
        // ============================================================
        // data parametresi 'any' olarak tanımlanmıştır
        // Bu, TypeScript'in 'unknown' hatası vermesini engeller
        // ÖNEMLİ: Başka bir tip kullanmayın!
        // ============================================================
        
        webviewView.webview.onDidReceiveMessage(async (data: any) => {
            // -------------------------------------------------------
            // Güvenlik Kontrolü
            // -------------------------------------------------------
            // Gelen verinin geçerli bir nesne olup olmadığını kontrol et
            if (!data || typeof data !== 'object') {
                return;
            }

            // Mesajı IncomingMessage tipine dönüştür
            const message = data as IncomingMessage;

            // Mesaj tipine göre işlem yap
            switch (message.type) {
                // -------------------------------------------------------
                // Kullanıcı Mesajı İşlemi
                // -------------------------------------------------------
                case 'userMessage':
                    await this._handleUserMessage(message.text || '');
                    break;
                    
                // -------------------------------------------------------
                // Komut Çalıştırma İşlemi (ONAY GEREKTİRİR)
                // -------------------------------------------------------
                case 'runCommand':
                    // Komutu doğrudan çalıştırma - önce onay iste
                    // Kullanıcı onaylamadan terminal açılmaz!
                    if (this._view) {
                        this._view.webview.postMessage({ 
                            type: 'requestConfirmation', 
                            command: message.command || '',
                            action: 'terminal'
                        });
                    }
                    break;
                    
                // -------------------------------------------------------
                // API Anahtarı Değişikliği İşlemi
                // -------------------------------------------------------
                case 'apiKeyChange':
                    await this._saveApiKey(message.model, message.key);
                    break;
                    
                // -------------------------------------------------------
                // Hızlı Eylem İşlemi
                // -------------------------------------------------------
                case 'quickAction':
                    this._handleQuickAction(message.action);
                    break;
                    
                // -------------------------------------------------------
                // Model Değişikliği İşlemi
                // -------------------------------------------------------
                case 'modelChange':
                    // İleride çoklu model desteği için hazır
                    break;
                    
                // -------------------------------------------------------
                // Kod Kopyalama İşlemi
                // -------------------------------------------------------
                case 'copyCode':
                    // Kod kopyalama işlemi VS Code tarafından otomatik yapılıyor
                    break;
                    
                // -------------------------------------------------------
                // KOMUT ONAY İŞLEMİ (ÇOK ÖNEMLİ)
                // -------------------------------------------------------
                case 'confirmCommand':
                    // Kullanıcı onayladı - komutu çalıştır
                    // Güvenlik: Sadece onay sonrası terminal çalışır!
                    this._runInTerminal(message.command || '');
                    break;
                    
                // -------------------------------------------------------
                // KOMUT İPTAL İŞLEMİ
                // -------------------------------------------------------
                case 'cancelCommand':
                    // Kullanıcı iptal etti - işlemi durdur
                    if (this._view) {
                        this._view.webview.postMessage({ 
                            type: 'commandCancelled', 
                            command: message.command || '' 
                        });
                    }
                    break;
            }
        });
    }

    /**
     * Kullanıcı mesajını işler ve AI'dan yanıt alır
     * 
     * @param text - Kullanıcının gönderdiği mesaj
     */
    private async _handleUserMessage(text: string): Promise<void> {
        // Webview yoksa işlemi durdur
        if (!this._view) {
            return;
        }

        // Kullanıcıya yazma efekti göster
        this._view.webview.postMessage({ type: 'aiTyping' });

        try {
            // -------------------------------------------------------
            // API Kontrolü
            // -------------------------------------------------------
            if (!this._geminiApi) {
                this._view.webview.postMessage({ 
                    type: 'error', 
                    message: 'Lütfen ayarlardan Gemini API anahtarını girin.' 
                });
                return;
            }

            // ============================================================
            // ÖNEMLİ: Model Adı Sabitleme
            // ============================================================
            // Model adı kesinlikle "gemini-2.0-flash" olmalı
            // NOT: "-exp" veya başka bir ek YOK!
            // Bu, 404 Not Found hatasını çözer
            // ============================================================
            
            const model = this._geminiApi.getGenerativeModel({ 
                model: "gemini-2.0-flash"  // Kesinlikle değiştirmeyin!
            });
            
            // AI'dan yanıt al
            const result = await model.generateContent(text);
            const response = result.response.text();
            
            // Yanıtı webview'e gönder
            this._view.webview.postMessage({ 
                type: 'aiResponse', 
                text: response,
                model: 'gemini'
            });
            
        } catch (err: unknown) {
            // Hata durumunda kullanıcıyı bilgilendir
            const errorMessage = err instanceof Error ? err.message : 'Bilinmeyen bir hata oluştu';
            this._view.webview.postMessage({ 
                type: 'error', 
                message: errorMessage 
            });
        }
    }

    /**
     * Terminalde komut çalıştırır
     * GÜVENLİK: Bu metot sadece kullanıcı onayladıktan sonra çağrılır!
     * 
     * @param command - Çalıştırılacak komut
     */
    private _runInTerminal(command: string): void {
        // Yeni terminal oluştur veya mevcut terminali kullan
        const terminal = vscode.window.activeTerminal || 
                         vscode.window.createTerminal('Anatolia Terminal');
        
        // Terminali göster
        terminal.show();
        
        // Komutu terminalde çalıştır
        vscode.commands.executeCommand('workbench.action.terminal.sendSequence', {
            text: command + '\r'
        });

        // Sonucu webview'e bildir (basit simülasyon)
        setTimeout(() => {
            if (this._view) {
                this._view.webview.postMessage({
                    type: 'commandResult',
                    command: command,
                    output: `$ ${command}\n[Komut çalıştırıldı]`,
                    exitCode: 0
                });
            }
        }, 500);
    }

    /**
     * API anahtarını kaydeder
     * 
     * @param provider - Model sağlayıcısı adı
     * @param key - API anahtarı
     */
    private async _saveApiKey(provider: string, key: string): Promise<void> {
        // Sağlayıcı tipini al
        const providerKey = provider as ModelProvider;
        
        // Güvenli depolamaya kaydet
        await this._context.secrets.store(`${providerKey}_key`, key);
        
        // API anahtarını haritaya ekle
        this._apiKeys.set(providerKey, key);
        
        // -------------------------------------------------------
        // Gemini API için özel işlem
        // -------------------------------------------------------
        if (provider === 'gemini') {
            this._geminiApi = new GoogleGenerativeAI(key);
        }
        
        // Kullanıcıya başarı mesajı göster
        if (this._view) {
            this._view.webview.postMessage({ 
                type: 'aiResponse', 
                text: '✅ API anahtarı başarıyla kaydedildi!',
                model: 'sistem'
            });
        }
        
        // VSCode bilgi mesajı göster
        vscode.window.showInformationMessage(`${provider.toUpperCase()} API anahtarı kaydedildi.`);
    }

    /**
     * Hızlı eylemleri işler
     * 
     * @param action - Eylem adı
     */
    private _handleQuickAction(action: string): void {
        // Terminal açma eylemi
        if (action === 'openTerminal') {
            vscode.window.createTerminal('AnatoliaAI').show();
        }
        
        // Dosya oluşturma eylemi
        if (action === 'createFile') {
            vscode.commands.executeCommand('explorer.newFile');
        }
        
        // Kod açıklama eylemi
        if (action === 'explainCode') {
            // Aktif editörde seçili kodu al
            const editor = vscode.window.activeTextEditor;
            if (editor) {
                const selection = editor.selection;
                const selectedText = editor.document.getText(selection);
                
                if (selectedText) {
                    // Seçili kodu açıklaması için AI'ya gönder
                    this._handleUserMessage(`Bu kodu açıkla: ${selectedText}`);
                } else {
                    vscode.window.showInformationMessage('Açıklamak için bir kod seçin.');
                }
            }
        }
    }

    // ============================================================
    // HTML Template - Webview HTML şablonu
    // ============================================================

    /**
     * Webview için HTML içeriğini döndürür
     * Tüm UI bileşenlerini ve scriptleri içerir
     * 
     * @returns HTML string
     */
    private _getHtmlForWebview(): string {
        return `<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta http-equiv="Content-Security-Policy"
  content="default-src 'none';
           font-src https://fonts.gstatic.com;
           style-src 'unsafe-inline' https://fonts.googleapis.com;
           script-src 'unsafe-inline';
           img-src data: vscode-resource: https:;" />
<title>AnatoliaAI</title>
<link rel="preconnect" href="https://fonts.googleapis.com" />
<link rel="stylesheet"
  href="https://fonts.googleapis.com/css2?family=Atkinson+Hyperlegible:ital,wght@0,400;0,700;1,400&family=JetBrains+Mono:wght@400;500&display=swap" />

<!-- ============================================================
     TYPESCRIPT INTERFACES (Referans)
     ============================================================ -->
<script>
  // Type definitions for the extension communication
  // These are embedded as comments for reference only
  /*
  type ModelProvider = 'gemini' | 'huggingface' | 'groq';
  
  interface WebviewMessage {
    type:
      | 'userMessage'
      | 'aiResponse'
      | 'aiTyping'
      | 'runCommand'
      | 'commandResult'
      | 'modelChange'
      | 'apiKeyChange'
      | 'quickAction'
      | 'copyCode'
      | 'error';
  }
  */
<\/script>

<style>
/* ── Reset & Base ────────────────────────────────────────────── */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

:root {
  --bg-0:       #0d0f14;
  --bg-1:       #13161e;
  --bg-2:       #1a1e28;
  --bg-3:       #222738;
  --bg-4:       #2a3045;

  --border:     #2e3550;
  --border-lit: #3d4a6a;

  --text-0:     #e8ecf4;
  --text-1:     #b0b9d0;
  --text-2:     #717d9a;
  --text-3:     #4a5270;

  --accent:     #38d9a9;
  --accent-dim: rgba(56,217,169,.15);
  --accent-2:   #5e9cff;
  --accent-2-dim: rgba(94,156,255,.15);
  --warn:       #ffb347;
  --err:        #ff6b6b;

  --radius-sm:  6px;
  --radius-md:  12px;
  --radius-lg:  18px;
  --radius-xl:  24px;

  --font-ui:    'Atkinson Hyperlegible', 'Segoe UI', sans-serif;
  --font-code:  'JetBrains Mono', 'Cascadia Code', monospace;

  --transition: 200ms cubic-bezier(.4,0,.2,1);
  --shadow-lg:  0 8px 32px rgba(0,0,0,.45);
}

html, body {
  height: 100%;
  background: var(--bg-0);
  color: var(--text-0);
  font-family: var(--font-ui);
  font-size: 13.5px;
  line-height: 1.6;
  overflow: hidden;
}

/* ── Layout Shell ────────────────────────────────────────────── */
#shell {
  display: grid;
  grid-template-rows: auto 1fr auto auto;
  height: 100vh;
  max-height: 100vh;
}

/* ── Header ──────────────────────────────────────────────────── */
#header {
  background: var(--bg-1);
  border-bottom: 1px solid var(--border);
  padding: 10px 14px;
  display: flex;
  align-items: center;
  gap: 10px;
  position: relative;
  z-index: 10;
}

#header .logo {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-shrink: 0;
}

#header .logo svg { color: var(--accent); }

#header .logo-text {
  font-weight: 700;
  font-size: 14px;
  letter-spacing: .04em;
  color: var(--text-0);
}

#header .logo-text span {
  color: var(--accent);
}

.divider-v {
  width: 1px;
  height: 22px;
  background: var(--border);
  flex-shrink: 0;
}

/* Model Selector */
#model-selector-wrap {
  display: flex;
  align-items: center;
  gap: 6px;
  flex: 1;
}

#model-selector {
  appearance: none;
  background: var(--bg-3);
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  color: var(--text-0);
  font-family: var(--font-ui);
  font-size: 12.5px;
  padding: 5px 30px 5px 10px;
  cursor: pointer;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%23717d9a' stroke-width='2'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E");
  background-repeat: no-repeat;
  background-position: right 8px center;
  transition: border-color var(--transition), background-color var(--transition);
}

#model-selector:hover, #model-selector:focus {
  border-color: var(--accent);
  outline: none;
  background-color: var(--bg-4);
}

.model-badge {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  font-size: 10.5px;
  font-weight: 700;
  letter-spacing: .06em;
  text-transform: uppercase;
  padding: 2px 8px;
  border-radius: 99px;
  border: 1px solid;
  flex-shrink: 0;
}

.model-badge.gemini     { color: #a78bfa; border-color: rgba(167,139,250,.3); background: rgba(167,139,250,.08); }
.model-badge.huggingface{ color: var(--warn); border-color: rgba(255,179,71,.3); background: rgba(255,179,71,.08); }
.model-badge.groq       { color: var(--accent); border-color: rgba(56,217,169,.3); background: rgba(56,217,169,.08); }

/* Settings Gear */
#settings-btn {
  background: var(--bg-3);
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  color: var(--text-2);
  cursor: pointer;
  width: 30px;
  height: 30px;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all var(--transition);
  flex-shrink: 0;
}

#settings-btn:hover { color: var(--accent); border-color: var(--accent); background: var(--accent-dim); }
#settings-btn.active { color: var(--accent); border-color: var(--accent); background: var(--accent-dim); }

#settings-btn svg {
  transition: transform 400ms cubic-bezier(.4,0,.2,1);
}
#settings-btn.active svg { transform: rotate(60deg); }

/* API Key Panel */
#api-key-panel {
  position: absolute;
  top: calc(100% + 6px);
  right: 14px;
  width: 300px;
  background: var(--bg-2);
  border: 1px solid var(--border-lit);
  border-radius: var(--radius-md);
  padding: 14px;
  box-shadow: var(--shadow-lg);
  z-index: 100;
  transform-origin: top right;
  transform: scaleY(0) translateY(-8px);
  opacity: 0;
  pointer-events: none;
  transition: transform 220ms cubic-bezier(.4,0,.2,1),
              opacity 220ms cubic-bezier(.4,0,.2,1);
}

#api-key-panel.open {
  transform: scaleY(1) translateY(0);
  opacity: 1;
  pointer-events: all;
}

#api-key-panel h4 {
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: .08em;
  color: var(--text-2);
  margin-bottom: 12px;
}

.api-field {
  margin-bottom: 10px;
}

.api-field label {
  display: block;
  font-size: 11.5px;
  color: var(--text-1);
  margin-bottom: 4px;
}

.api-field input {
  width: 100%;
  background: var(--bg-3);
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  color: var(--text-0);
  font-family: var(--font-code);
  font-size: 11px;
  padding: 6px 10px;
  transition: border-color var(--transition);
}

.api-field input:focus {
  outline: none;
  border-color: var(--accent);
}

.api-field input::placeholder { color: var(--text-3); }

#save-keys-btn {
  width: 100%;
  margin-top: 4px;
  padding: 7px;
  background: var(--accent-dim);
  border: 1px solid var(--accent);
  border-radius: var(--radius-sm);
  color: var(--accent);
  font-family: var(--font-ui);
  font-size: 12px;
  font-weight: 700;
  letter-spacing: .04em;
  cursor: pointer;
  transition: background var(--transition);
}

#save-keys-btn:hover { background: rgba(56,217,169,.25); }

/* ── Chat Area ───────────────────────────────────────────────── */
#chat {
  overflow-y: auto;
  padding: 20px 16px;
  display: flex;
  flex-direction: column;
  gap: 16px;
  scroll-behavior: smooth;
}

#chat::-webkit-scrollbar { width: 4px; }
#chat::-webkit-scrollbar-track { background: transparent; }
#chat::-webkit-scrollbar-thumb { background: var(--bg-4); border-radius: 99px; }
#chat::-webkit-scrollbar-thumb:hover { background: var(--border-lit); }

/* Welcome */
#welcome {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 12px;
  padding: 40px 20px;
  text-align: center;
  color: var(--text-2);
}

#welcome .w-icon {
  width: 52px; height: 52px;
  background: var(--accent-dim);
  border: 1px solid rgba(56,217,169,.2);
  border-radius: var(--radius-xl);
  display: flex; align-items: center; justify-content: center;
  color: var(--accent);
}

#welcome h2 {
  font-size: 16px;
  color: var(--text-0);
  font-weight: 700;
  letter-spacing: -.01em;
}

#welcome p { font-size: 12.5px; max-width: 220px; }

/* Message Bubbles */
.msg-row {
  display: flex;
  gap: 10px;
  max-width: 100%;
  animation: msgIn 280ms cubic-bezier(.4,0,.2,1) both;
}

@keyframes msgIn {
  from { opacity:0; transform: translateY(10px); }
  to   { opacity:1; transform: translateY(0); }
}

.msg-row.user {
  flex-direction: row-reverse;
}

.msg-avatar {
  width: 28px; height: 28px;
  border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  font-size: 11px; font-weight: 700;
  flex-shrink: 0;
  margin-top: 2px;
}

.msg-row.user .msg-avatar {
  background: var(--accent-2-dim);
  border: 1px solid rgba(94,156,255,.3);
  color: var(--accent-2);
}

.msg-row.ai .msg-avatar {
  background: var(--accent-dim);
  border: 1px solid rgba(56,217,169,.3);
  color: var(--accent);
}

.msg-body {
  flex: 1;
  max-width: calc(100% - 40px);
}

.msg-row.user .msg-body {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
}

.msg-bubble {
  display: inline-block;
  padding: 10px 14px;
  border-radius: var(--radius-lg);
  font-size: 13px;
  line-height: 1.65;
  word-break: break-word;
  max-width: 100%;
}

.msg-row.user .msg-bubble {
  background: var(--bg-4);
  border: 1px solid var(--border-lit);
  border-bottom-right-radius: var(--radius-sm);
  color: var(--text-0);
}

.msg-row.ai .msg-bubble {
  background: var(--bg-2);
  border: 1px solid var(--border);
  border-bottom-left-radius: var(--radius-sm);
  color: var(--text-0);
  width: 100%;
}

.msg-meta {
  font-size: 10.5px;
  color: var(--text-3);
  margin-top: 5px;
  padding: 0 4px;
}

/* Code Blocks */
.code-block {
  margin: 10px 0;
  background: var(--bg-0);
  border: 1px solid var(--border);
  border-radius: var(--radius-md);
  overflow: hidden;
}

.code-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 6px 12px;
  background: var(--bg-1);
  border-bottom: 1px solid var(--border);
}

.code-lang {
  font-family: var(--font-code);
  font-size: 10px;
  text-transform: uppercase;
  letter-spacing: .08em;
  color: var(--text-2);
}

.code-actions {
  display: flex;
  gap: 6px;
}

.code-btn {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 3px 8px;
  border-radius: 4px;
  font-size: 10.5px;
  font-weight: 700;
  cursor: pointer;
  border: 1px solid;
  transition: all var(--transition);
  font-family: var(--font-ui);
  letter-spacing: .03em;
}

.copy-btn {
  color: var(--text-2);
  border-color: var(--border);
  background: transparent;
}

.copy-btn:hover { color: var(--accent); border-color: var(--accent); background: var(--accent-dim); }
.copy-btn.copied { color: var(--accent); border-color: var(--accent); background: var(--accent-dim); }

.run-btn {
  color: var(--warn);
  border-color: rgba(255,179,71,.3);
  background: rgba(255,179,71,.07);
}

.run-btn:hover { background: rgba(255,179,71,.15); border-color: var(--warn); }

code.inline {
  font-family: var(--font-code);
  font-size: .88em;
  background: var(--bg-3);
  padding: 1px 5px;
  border-radius: 4px;
  color: var(--accent);
}

pre {
  padding: 14px 16px;
  overflow-x: auto;
  font-family: var(--font-code);
  font-size: 12px;
  line-height: 1.7;
  color: var(--text-0);
}

pre::-webkit-scrollbar { height: 4px; }
pre::-webkit-scrollbar-track { background: transparent; }
pre::-webkit-scrollbar-thumb { background: var(--bg-4); border-radius: 99px; }

/* Syntax highlight — minimal */
.tok-kw   { color: #79c0ff; }
.tok-str  { color: #a5d6ff; }
.tok-cmt  { color: #4a5270; font-style: italic; }
.tok-fn   { color: var(--accent); }
.tok-num  { color: #f8c555; }
.tok-op   { color: #ff7b72; }
.tok-cls  { color: #ffa657; }
.tok-var  { color: var(--text-0); }

/* Terminal Runner */
.terminal-runner {
  margin-top: 8px;
  border: 1px solid var(--border);
  border-radius: var(--radius-md);
  overflow: hidden;
}

.terminal-cmd {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 12px;
  background: var(--bg-1);
  font-family: var(--font-code);
  font-size: 12px;
  color: var(--accent);
}

.terminal-cmd::before {
  content: '$';
  color: var(--text-3);
}

.terminal-output {
  padding: 10px 14px;
  background: #080a0f;
  font-family: var(--font-code);
  font-size: 11.5px;
  color: #a8f0d0;
  white-space: pre-wrap;
  word-break: break-all;
  display: none;
  max-height: 150px;
  overflow-y: auto;
  border-top: 1px solid var(--border);
}

.terminal-output.visible { display: block; }

/* Spinner */
@keyframes spin { to { transform: rotate(360deg); } }

.spinner {
  width: 12px; height: 12px;
  border: 2px solid var(--border);
  border-top-color: var(--accent);
  border-radius: 50%;
  animation: spin 700ms linear infinite;
  flex-shrink: 0;
}

/* Typing indicator */
.typing-indicator {
  display: flex;
  align-items: center;
  gap: 5px;
  padding: 10px 14px;
}

.typing-dot {
  width: 6px; height: 6px;
  border-radius: 50%;
  background: var(--text-3);
  animation: typingBounce 1.2s ease-in-out infinite;
}

.typing-dot:nth-child(2) { animation-delay: .2s; }
.typing-dot:nth-child(3) { animation-delay: .4s; }

@keyframes typingBounce {
  0%, 60%, 100% { transform: translateY(0); background: var(--text-3); }
  30% { transform: translateY(-6px); background: var(--accent); }
}

/* ── Quick Actions Bar ───────────────────────────────────────── */
#quick-actions {
  padding: 8px 16px 0;
  display: flex;
  gap: 6px;
  flex-wrap: wrap;
  background: var(--bg-0);
}

.qa-badge {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 5px 10px;
  border-radius: 99px;
  font-size: 11.5px;
  font-weight: 700;
  letter-spacing: .03em;
  cursor: pointer;
  border: 1px solid;
  background: transparent;
  transition: all var(--transition);
  font-family: var(--font-ui);
  white-space: nowrap;
}

.qa-badge.terminal {
  color: var(--accent);
  border-color: rgba(56,217,169,.3);
}
.qa-badge.terminal:hover { background: var(--accent-dim); }

.qa-badge.create {
  color: var(--accent-2);
  border-color: rgba(94,156,255,.3);
}
.qa-badge.create:hover { background: var(--accent-2-dim); }

.qa-badge.explain {
  color: var(--warn);
  border-color: rgba(255,179,71,.3);
}
.qa-badge.explain:hover { background: rgba(255,179,71,.08); }

.qa-badge.clear {
  color: var(--text-2);
  border-color: var(--border);
}
.qa-badge.clear:hover { color: var(--err); border-color: var(--err); background: rgba(255,107,107,.08); }

/* ── Input Area ──────────────────────────────────────────────── */
#input-area {
  padding: 10px 14px 14px;
  background: var(--bg-0);
  border-top: 1px solid var(--border);
}

#input-wrap {
  display: flex;
  align-items: flex-end;
  gap: 8px;
  background: var(--bg-2);
  border: 1px solid var(--border);
  border-radius: var(--radius-xl);
  padding: 6px 6px 6px 14px;
  transition: border-color var(--transition), box-shadow var(--transition);
}

#input-wrap:focus-within {
  border-color: var(--border-lit);
  box-shadow: 0 0 0 3px rgba(56,217,169,.07);
}

#input {
  flex: 1;
  background: transparent;
  border: none;
  outline: none;
  color: var(--text-0);
  font-family: var(--font-ui);
  font-size: 13px;
  line-height: 1.5;
  resize: none;
  max-height: 130px;
  min-height: 24px;
  overflow-y: auto;
  padding: 4px 0;
}

#input::placeholder { color: var(--text-3); }
#input::-webkit-scrollbar { width: 3px; }
#input::-webkit-scrollbar-thumb { background: var(--bg-4); }

#send-btn {
  width: 36px; height: 36px;
  border-radius: 50%;
  border: none;
  background: var(--accent);
  color: #0a1a13;
  cursor: pointer;
  display: flex; align-items: center; justify-content: center;
  flex-shrink: 0;
  transition: transform var(--transition), background var(--transition), box-shadow var(--transition);
}

#send-btn:hover { transform: scale(1.08); box-shadow: 0 0 12px rgba(56,217,169,.4); }
#send-btn:active { transform: scale(.95); }
#send-btn:disabled { background: var(--bg-4); color: var(--text-3); box-shadow: none; transform: none; cursor: not-allowed; }

#char-hint {
  text-align: right;
  font-size: 10px;
  color: var(--text-3);
  margin-top: 4px;
  padding-right: 6px;
  height: 12px;
}

/* ── Scrollbar in chat ───────────────────────────────────────── */
.msg-row.ai .msg-bubble p + p { margin-top: 8px; }
.msg-row.ai .msg-bubble ul, .msg-row.ai .msg-bubble ol { padding-left: 18px; margin: 6px 0; }
.msg-row.ai .msg-bubble li { margin-bottom: 3px; }

/* ── Notification Toast ──────────────────────────────────────── */
#toast {
  position: fixed;
  bottom: 20px;
  left: 50%;
  transform: translateX(-50%) translateY(20px);
  background: var(--bg-3);
  border: 1px solid var(--border-lit);
  border-radius: 99px;
  padding: 7px 16px;
  font-size: 12px;
  color: var(--accent);
  pointer-events: none;
  opacity: 0;
  transition: opacity 200ms, transform 200ms;
  white-space: nowrap;
  z-index: 999;
}

#toast.show {
  opacity: 1;
  transform: translateX(-50%) translateY(0);
}

/* ── Status Dot ──────────────────────────────────────────────── */
.status-dot {
  width: 6px; height: 6px;
  border-radius: 50%;
  background: var(--accent);
  box-shadow: 0 0 6px var(--accent);
  flex-shrink: 0;
  animation: pulse 2s ease-in-out infinite;
}

@keyframes pulse {
  0%, 100% { opacity: 1; }
  50%       { opacity: .4; }
}

/* ── Scrolled-to-bottom indicator ───────────────────────────── */
#scroll-btn {
  position: absolute;
  bottom: 14px;
  left: 50%;
  transform: translateX(-50%) translateY(0);
  background: var(--bg-3);
  border: 1px solid var(--border-lit);
  border-radius: 99px;
  padding: 5px 12px;
  font-size: 11px;
  color: var(--text-1);
  cursor: pointer;
  display: none;
  align-items: center;
  gap: 5px;
  z-index: 20;
  transition: all var(--transition);
}

#scroll-btn:hover { background: var(--bg-4); color: var(--accent); }

/* ── Confirmation Modal ─────────────────────────────────────── */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.75);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
  opacity: 0;
  visibility: hidden;
  transition: opacity 200ms ease, visibility 200ms ease;
}

.modal-overlay.show {
  opacity: 1;
  visibility: visible;
}

.modal-container {
  background: var(--bg-2);
  border: 1px solid var(--border-lit);
  border-radius: var(--radius-lg);
  width: 90%;
  max-width: 420px;
  box-shadow: var(--shadow-lg);
  transform: scale(0.9) translateY(20px);
  transition: transform 220ms cubic-bezier(.4,0,.2,1);
}

.modal-overlay.show .modal-container {
  transform: scale(1) translateY(0);
}

.modal-header {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 16px 18px;
  border-bottom: 1px solid var(--border);
  color: var(--warn);
  font-weight: 700;
  font-size: 14px;
}

.modal-header svg {
  flex-shrink: 0;
}

.modal-body {
  padding: 18px;
}

.modal-warning {
  color: var(--text-1);
  font-size: 13px;
  margin-bottom: 10px;
}

.modal-command-preview {
  background: var(--bg-0);
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  padding: 12px 14px;
  margin-bottom: 14px;
  overflow-x: auto;
}

.modal-command-preview code {
  font-family: var(--font-code);
  font-size: 12px;
  color: var(--accent);
  white-space: pre-wrap;
  word-break: break-all;
}

.modal-info {
  color: var(--text-2);
  font-size: 12px;
  margin: 0;
}

.modal-actions {
  display: flex;
  gap: 10px;
  padding: 14px 18px;
  border-top: 1px solid var(--border);
  justify-content: flex-end;
}

.modal-btn {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 8px 16px;
  border-radius: var(--radius-sm);
  font-family: var(--font-ui);
  font-size: 12.5px;
  font-weight: 700;
  cursor: pointer;
  transition: all var(--transition);
  border: 1px solid;
}

.modal-btn-cancel {
  background: transparent;
  border-color: var(--border);
  color: var(--text-1);
}

.modal-btn-cancel:hover {
  background: rgba(255, 107, 107, 0.1);
  border-color: var(--err);
  color: var(--err);
}

.modal-btn-confirm {
  background: var(--accent-dim);
  border-color: var(--accent);
  color: var(--accent);
}

.modal-btn-confirm:hover {
  background: rgba(56, 217, 169, 0.25);
}
</style>
</head>
<body>

<div id="shell">

  <!-- ── Header ──────────────────────────────────────────────── -->
  <header id="header">
    <div class="logo">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>
      </svg>
      <span class="logo-text">Anatolia<span>AI</span></span>
    </div>

    <div class="divider-v"></div>

    <div id="model-selector-wrap">
      <select id="model-selector">
        <option value="gemini">✦ Gemini</option>
        <option value="huggingface">⊕ Hugging Face</option>
        <option value="groq">◈ Groq</option>
      </select>
      <span id="model-badge" class="model-badge gemini">GEMINI</span>
    </div>

    <div class="status-dot" title="Bağlantı aktif"></div>

    <button id="settings-btn" title="API Ayarları">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
           stroke="currentColor" stroke-width="2" stroke-linecap="round">
        <circle cx="12" cy="12" r="3"/>
        <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>
      </svg>
    </button>

    <!-- API Key Dropdown Panel -->
    <div id="api-key-panel">
      <h4>API Anahtarları</h4>

      <div class="api-field">
        <label>Gemini API Key</label>
        <input type="password" id="key-gemini" placeholder="AIza..." />
      </div>

      <div class="api-field">
        <label>Hugging Face Token</label>
        <input type="password" id="key-hf" placeholder="hf_..." />
      </div>

      <div class="api-field">
        <label>Groq API Key</label>
        <input type="password" id="key-groq" placeholder="gsk_..." />
      </div>

      <button id="save-keys-btn">Anahtarları Kaydet</button>
    </div>
  </header>

  <!-- ── Chat ──────────────────────────────────────────────────── -->
  <div id="chat" role="log" aria-live="polite">
    <div id="welcome">
      <div class="w-icon">
        <svg width="26" height="26" viewBox="0 0 24 24" fill="none"
             stroke="currentColor" stroke-width="1.5">
          <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>
        </svg>
      </div>
      <h2>AnatoliaAI'ya Hoş Geldin</h2>
      <p>Kodunu yaz, düzelt, terminale gönder — her şey tek yerden.</p>
    </div>
  </div>

  <!-- ── Quick Actions ─────────────────────────────────────────── -->
  <div id="quick-actions">
    <button class="qa-badge terminal" data-action="openTerminal">
      <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="4 17 10 11 4 5"/><line x1="12" y1="19" x2="20" y2="19"/></svg>
      Terminal Aç
    </button>
    <button class="qa-badge create" data-action="createFile">
      <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="12" y1="18" x2="12" y2="12"/><line x1="9" y1="15" x2="15" y2="15"/></svg>
      Dosya Oluştur
    </button>
    <button class="qa-badge explain" data-action="explainCode">
      <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>
      Kodu Açıkla
    </button>
    <button class="qa-badge clear" id="clear-btn">
      <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/></svg>
      Temizle
    </button>
  </div>

  <!-- ── Input ─────────────────────────────────────────────────── -->
  <div id="input-area">
    <div id="input-wrap">
      <textarea id="input" rows="1"
                placeholder="Bir şey sor ya da komut ver…"
                aria-label="Mesaj gir"></textarea>
      <button id="send-btn" title="Gönder (Enter)">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
             stroke="currentColor" stroke-width="2.5" stroke-linecap="round">
          <line x1="22" y1="2" x2="11" y2="13"/>
          <polygon points="22 2 15 22 11 13 2 9 22 2"/>
        </svg>
      </button>
    </div>
    <div id="char-hint"></div>
  </div>
</div>

<!-- Toast -->
<div id="toast"></div>

<!-- Confirmation Modal -->
<div id="confirm-modal" class="modal-overlay">
    <div class="modal-container">
        <div class="modal-header">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
            </svg>
            <span>İşlem Onayı</span>
        </div>
        <div class="modal-body">
            <p class="modal-warning">Aşağıdaki komut çalıştırılacak:</p>
            <div class="modal-command-preview">
                <code id="confirm-command-text"></code>
            </div>
            <p class="modal-info">Bu işlemi onaylıyor musunuz?</p>
        </div>
        <div class="modal-actions">
            <button id="confirm-cancel-btn" class="modal-btn modal-btn-cancel">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <line x1="18" y1="6" x2="6" y2="18"/>
                    <line x1="6" y1="6" x2="18" y2="18"/>
                </svg>
                İptal
            </button>
            <button id="confirm-ok-btn" class="modal-btn modal-btn-confirm">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="20 6 9 17 4 12"/>
                </svg>
                Onayla
            </button>
        </div>
    </div>
</div>

<script>
/* ═══════════════════════════════════════════════════════════════
   AnatoliaAI Webview Script
   ═══════════════════════════════════════════════════════════════ */

(function () {
  'use strict';

  /* ── VS Code API ─────────────────────────────────────────── */
  let vscode;
  try { vscode = acquireVsCodeApi(); } catch (_) { vscode = null; }

  function postMsg(payload) {
    if (vscode) vscode.postMessage(payload);
    else console.log('[AnatoliaAI → Extension]', payload);
  }

  /* ── State ───────────────────────────────────────────────── */
  let currentModel = 'gemini';
  let isWaiting    = false;
  let pendingCommand = null; // Bekleyen komut için

  /* ── DOM Refs ────────────────────────────────────────────── */
  const chat       = document.getElementById('chat');
  const welcome    = document.getElementById('welcome');
  const input      = document.getElementById('input');
  const sendBtn    = document.getElementById('send-btn');
  const charHint   = document.getElementById('char-hint');
  const modelSel   = document.getElementById('model-selector');
  const modelBadge = document.getElementById('model-badge');
  const settingsBtn= document.getElementById('settings-btn');
  const apiPanel   = document.getElementById('api-key-panel');
  const saveKeysBtn= document.getElementById('save-keys-btn');
  const clearBtn   = document.getElementById('clear-btn');
  const toast      = document.getElementById('toast');
  const modal      = document.getElementById('confirm-modal');
  const modalCmd   = document.getElementById('confirm-command-text');
  const confirmOk  = document.getElementById('confirm-ok-btn');
  const confirmCancel = document.getElementById('confirm-cancel-btn');

  /* ── Textarea auto-resize ────────────────────────────────── */
  input.addEventListener('input', () => {
    input.style.height = 'auto';
    input.style.height = Math.min(input.scrollHeight, 130) + 'px';
    const len = input.value.length;
    charHint.textContent = len > 200 ? \`\${len} karakter\` : '';
  });

  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  });

  sendBtn.addEventListener('click', sendMessage);

  /* ── Model Selector ─────────────────────────────────────── */
  modelSel.addEventListener('change', () => {
    currentModel = modelSel.value;
    updateModelBadge();
    postMsg({ type: 'modelChange', model: currentModel });
  });

  function updateModelBadge() {
    const labels = { gemini: 'GEMINI', huggingface: 'HF', groq: 'GROQ' };
    modelBadge.textContent = labels[currentModel] || currentModel.toUpperCase();
    modelBadge.className = 'model-badge ' + currentModel;
  }

  /* ── Settings Panel ─────────────────────────────────────── */
  settingsBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    const open = apiPanel.classList.toggle('open');
    settingsBtn.classList.toggle('active', open);
  });

  document.addEventListener('click', (e) => {
    if (!apiPanel.contains(e.target) && e.target !== settingsBtn) {
      apiPanel.classList.remove('open');
      settingsBtn.classList.remove('active');
    }
  });

  saveKeysBtn.addEventListener('click', () => {
    const keys = {
      gemini:      document.getElementById('key-gemini').value.trim(),
      huggingface: document.getElementById('key-hf').value.trim(),
      groq:        document.getElementById('key-groq').value.trim(),
    };

    Object.entries(keys).forEach(([model, key]) => {
      if (key) postMsg({ type: 'apiKeyChange', model, key });
    });

    apiPanel.classList.remove('open');
    settingsBtn.classList.remove('active');
    showToast('✓ Anahtarlar kaydedildi');
  });

  /* ── Quick Actions ───────────────────────────────────────── */
  document.querySelectorAll('.qa-badge[data-action]').forEach(btn => {
    btn.addEventListener('click', () => {
      const action = btn.dataset.action;
      postMsg({ type: 'quickAction', action });
      showToast(\`⚡ \${btn.textContent.trim()}\`);
    });
  });

  clearBtn.addEventListener('click', () => {
    chat.innerHTML = '';
    chat.appendChild(welcome);
    showToast('Sohbet temizlendi');
  });

  /* ── Confirmation Modal ─────────────────────────────────── */
  function showConfirmModal(command) {
    pendingCommand = command;
    modalCmd.textContent = command;
    modal.classList.add('show');
  }

  function hideConfirmModal() {
    pendingCommand = null;
    modal.classList.remove('show');
  }

  // Onayla butonu
  confirmOk.addEventListener('click', () => {
    if (pendingCommand) {
      postMsg({ type: 'confirmCommand', command: pendingCommand });
      hideConfirmModal();
      showToast('✓ Komut çalıştırılıyor...');
    }
  });

  // İptal butonu
  confirmCancel.addEventListener('click', () => {
    if (pendingCommand) {
      postMsg({ type: 'cancelCommand', command: pendingCommand });
      hideConfirmModal();
      showToast('✗ Komut iptal edildi');
    }
  });

  // Modal dışına tıklama ile kapatma
  modal.addEventListener('click', (e) => {
    if (e.target === modal) {
      if (pendingCommand) {
        postMsg({ type: 'cancelCommand', command: pendingCommand });
      }
      hideConfirmModal();
      showToast('✗ Komut iptal edildi');
    }
  });

  // ESC tuşu ile kapatma
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modal.classList.contains('show')) {
      if (pendingCommand) {
        postMsg({ type: 'cancelCommand', command: pendingCommand });
      }
      hideConfirmModal();
      showToast('✗ Komut iptal edildi');
    }
  });

  /* ── Send Message ───────────────────────────────────────── */
  function sendMessage() {
    const text = input.value.trim();
    if (!text || isWaiting) return;

    hideWelcome();
    appendUserMsg(text);
    input.value = '';
    input.style.height = 'auto';

    postMsg({ type: 'userMessage', text });
    setWaiting(true);

    // Demo: remove in production — extension responds via onDidReceiveMessage
    if (!vscode) {
      setTimeout(() => simulateAiResponse(text), 1100);
    }
  }

  function setWaiting(val) {
    isWaiting   = val;
    sendBtn.disabled = val;
  }

  /* ── Append User Message ─────────────────────────────────── */
  function appendUserMsg(text) {
    const row = el('div', 'msg-row user');
    row.innerHTML = \`
      <div class="msg-avatar">SİZ</div>
      <div class="msg-body">
        <div class="msg-bubble">\${escHtml(text)}</div>
        <div class="msg-meta">\${now()}</div>
      </div>\`;
    chat.appendChild(row);
    scrollDown();
  }

  /* ── Append AI Message ───────────────────────────────────── */
  function appendAiMsg(text, modelLabel) {
    const row = el('div', 'msg-row ai');
    const initials = (modelLabel || currentModel).substring(0, 2).toUpperCase();

    row.innerHTML = \`
      <div class="msg-avatar">\${initials}</div>
      <div class="msg-body">
        <div class="msg-bubble">\${renderMarkdown(text)}</div>
        <div class="msg-meta">\${modelLabel || currentModel} · \${now()}</div>
      </div>\`;

    chat.appendChild(row);
    attachCodeActions(row);
    scrollDown();
    setWaiting(false);
  }

  /* ── Typing Indicator ────────────────────────────────────── */
  function showTyping() {
    removeTyping();
    const row = el('div', 'msg-row ai');
    row.id = 'typing-row';
    row.innerHTML = \`
      <div class="msg-avatar">AI</div>
      <div class="msg-body">
        <div class="msg-bubble">
          <div class="typing-indicator">
            <div class="typing-dot"></div>
            <div class="typing-dot"></div>
            <div class="typing-dot"></div>
          </div>
        </div>
      </div>\`;
    chat.appendChild(row);
    scrollDown();
  }

  function removeTyping() {
    const t = document.getElementById('typing-row');
    if (t) t.remove();
  }

  /* ── Markdown Renderer (minimal, safe) ───────────────────── */
  function renderMarkdown(raw) {
    let s = escHtml(raw);

    // Code blocks \`\`\`lang\\n...\\n\`\`\`
    s = s.replace(/\`\`\`(\\w*)\\n([\\s\\S]*?)\`\`\`/g, (_m, lang, code) => {
      const isCmd = /^(npm|yarn|pnpm|git|cd|ls|mkdir|touch|python|node|npx|pip)/.test(code.trim());
      const highlighted = syntaxHighlight(unescHtml(code.trim()), lang);
      return \`
        <div class="code-block">
          <div class="code-header">
            <span class="code-lang">\${lang || 'code'}</span>
            <div class="code-actions">
              \${isCmd ? \`<button class="code-btn run-btn" data-cmd="\${escAttr(code.trim())}">▶ Terminalde Çalıştır</button>\` : ''}
              <button class="code-btn copy-btn" data-code="\${escAttr(code.trim())}">
                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
                Kopyala
              </button>
            </div>
          </div>
          <pre>\${highlighted}</pre>
        </div>\`;
    });

    // Inline code
    s = s.replace(/\`([^\`]+)\`/g, '<code class="inline">$1</code>');

    // Bold
    s = s.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');

    // Italic
    s = s.replace(/\*(.+?)\*/g, '<em>$1</em>');

    // Newlines → paragraphs (simple)
    s = '<p>' + s.replace(/\\n\\n+/g, '</p><p>').replace(/\\n/g, '<br>') + '</p>';

    return s;
  }

  /* ── Syntax Highlighting (minimal token-based) ────────────── */
  function syntaxHighlight(code, lang) {
    let s = escHtml(code);

    if (['js','ts','jsx','tsx','javascript','typescript'].includes(lang)) {
      s = s
        .replace(/\\/\\/.*$/gm, m => \`<span class="tok-cmt">\${m}</span>\`)
        .replace(/\\b(const|let|var|function|return|if|else|for|while|class|import|export|from|default|async|await|typeof|new|this|=>)\\b/g,
          '<span class="tok-kw">$1</span>')
        .replace(/("|')(.*?)(\\1)/g, '<span class="tok-str">$1$2$3</span>')
        .replace(/\\b(\\d+\\.?\\d*)\\b/g, '<span class="tok-num">$1</span>')
        .replace(/\\b([A-Z][a-zA-Z]+)\\b/g, '<span class="tok-cls">$1</span>');
    }

    if (['bash','sh','shell','zsh'].includes(lang)) {
      s = s
        .replace(/#.*$/gm, m => \`<span class="tok-cmt">\${m}</span>\`)
        .replace(/\\b(npm|yarn|git|cd|ls|mkdir|touch|echo|export|source|node|python|pip|npx)\\b/g,
          '<span class="tok-kw">$1</span>')
        .replace(/(")(.*?)(")/g, '<span class="tok-str">$1$2$3</span>');
    }

    return s;
  }

  /* ── Code Block Actions ──────────────────────────────────── */
  function attachCodeActions(container) {
    container.querySelectorAll('.copy-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const code = btn.dataset.code || '';
        navigator.clipboard.writeText(code).catch(() => {});
        postMsg({ type: 'copyCode', code });
        btn.textContent = '✓ Kopyalandı';
        btn.classList.add('copied');
        setTimeout(() => {
          btn.innerHTML = \`<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg> Kopyala\`;
          btn.classList.remove('copied');
        }, 2000);
      });
    });

    container.querySelectorAll('.run-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const cmd = btn.dataset.cmd || '';
        runTerminalCommand(cmd, btn);
      });
    });
  }

  /* ── Terminal Runner ─────────────────────────────────────── */
  function runTerminalCommand(cmd, triggerBtn) {
    const block = triggerBtn.closest('.code-block');

    // Show spinner
    triggerBtn.innerHTML = '<span class="spinner"></span> Çalışıyor…';
    triggerBtn.disabled = true;

    // Build output panel if not exists
    let outputPanel = block.querySelector('.terminal-output');
    if (!outputPanel) {
      outputPanel = el('div', 'terminal-output');
      block.appendChild(outputPanel);
    }
    outputPanel.textContent = '';
    outputPanel.classList.remove('visible');

    // Add terminal runner header
    let runner = block.querySelector('.terminal-runner');
    if (!runner) {
      runner = el('div', 'terminal-runner');
      runner.innerHTML = \`<div class="terminal-cmd">\${escHtml(cmd)}</div>\`;
      block.insertBefore(runner, block.querySelector('pre'));
    }

    postMsg({ type: 'runCommand', command: cmd });

    // Demo fallback
    if (!vscode) {
      setTimeout(() => {
        triggerBtn.innerHTML = '✓ Tamamlandı';
        outputPanel.textContent = \`\$ \${cmd}\\nadded 42 packages in 1.8s\\n[exit 0]\`;
        outputPanel.classList.add('visible');
        triggerBtn.disabled = false;
      }, 1800);
    }
  }

  /* ── Extension → Webview Messages ───────────────────────── */
  window.addEventListener('message', (event) => {
    const raw = event.data;
    if (!raw || typeof raw !== 'object') return;

    const msg = raw;

    switch (msg.type) {
      case 'aiResponse': {
        removeTyping();
        appendAiMsg(msg.text || '', msg.model);
        break;
      }

      case 'aiTyping': {
        showTyping();
        break;
      }

      case 'commandResult': {
        // Find all run-btns and match by command
        document.querySelectorAll('.run-btn').forEach(btn => {
          if (btn.dataset.cmd === msg.command) {
            btn.innerHTML = msg.exitCode === 0 ? '✓ Tamamlandı' : '✗ Hata';
            btn.disabled = false;

            const block  = btn.closest('.code-block');
            let output = block.querySelector('.terminal-output');
            if (!output) {
              output = el('div', 'terminal-output');
              block.appendChild(output);
            }
            output.textContent = msg.output || '';
            output.classList.add('visible');
          }
        });
        break;
      }

      case 'error': {
        removeTyping();
        appendAiMsg(\`⚠ Hata: \${msg.message}\`, 'sistem');
        break;
      }
    }
  });

  /* ── Demo Simulation (no extension context) ──────────────── */
  function simulateAiResponse(userText) {
    showTyping();
    setTimeout(() => {
      removeTyping();
      const responses = [
        \`Tabii! Projenizi kurmak için şu adımları takip edebilirsiniz:

\\\`\\\`\\\`bash
npm install
\\\`\\\`\\\`

Kurulum tamamlandıktan sonra geliştirme sunucusunu başlatın:

\\\`\\\`\\\`bash
npm run dev
\\\`\\\`\\\`

Her şey yolundaysa uygulama \\\`http://localhost:3000\\\` adresinde çalışıyor olacak.\`,

        \`İşte basit bir TypeScript interface örneği:

\\\`\\\`\\\`typescript
interface AnatoliaMessage {
  type: 'userMessage' | 'aiResponse';
  text: string;
  timestamp: number;
  model?: 'gemini' | 'huggingface' | 'groq';
}

function handleMessage(msg: unknown): void {
  const m = msg as AnatoliaMessage;
  console.log(m.text);
}
\\\`\\\`\\\`

Bu yapı \\\`data is unknown\\\` (TS18046) hatasını önler.\`,

        \`Anladım! **\${userText.substring(0, 30)}** konusunda yardımcı olabilirim.

Şu adımları deneyebilirsiniz:
- Önce mevcut durumu analiz edin
- Sonra düzeltmeyi uygulayın
- Son olarak test edin

Daha fazla detay ister misiniz?\`
      ];
      appendAiMsg(responses[Math.floor(Math.random() * responses.length)], currentModel);
    }, 1200);
  }

  /* ── Helpers ─────────────────────────────────────────────── */
  function hideWelcome() {
    if (welcome.parentNode) welcome.remove();
  }

  function scrollDown() {
    requestAnimationFrame(() => { chat.scrollTop = chat.scrollHeight; });
  }

  function now() {
    return new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
  }

  function el(tag, cls) {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    return e;
  }

  function escHtml(s) {
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '<')
      .replace(/>/g, '>')
      .replace(/"/g, '"')
      .replace(/'/g, '&#x27;');
  }

  function unescHtml(s) {
    return s
      .replace(/&amp;/g, '&')
      .replace(/</g, '<')
      .replace(/>/g, '>')
      .replace(/"/g, '"')
      .replace(/&#x27;/g, "'");
  }

  function escAttr(s) {
    return String(s).replace(/"/g, '"');
  }

  function showToast(msg) {
    toast.textContent = msg;
    toast.classList.add('show');
    clearTimeout(toast._t);
    toast._t = setTimeout(() => toast.classList.remove('show'), 2400);
  }

  /* ── Restore State (vscode.getState) ─────────────────────── */
  if (vscode) {
    const saved = vscode.getState();
    if (saved && saved.model) {
      currentModel = saved.model;
      modelSel.value = currentModel;
      updateModelBadge();
    }
  }

  modelSel.addEventListener('change', () => {
    if (vscode) vscode.setState({ model: currentModel });
  });

})();
</script>
</body>
</html>`;
    }
}

