# AnatoliaAI - User Confirmation Feature Implementation Plan

## Task Overview
Add a user confirmation mechanism before executing terminal commands in the AnatoliaAI VS Code extension.

## Implementation Steps

### 1. Update TypeScript Interfaces (chatPanel.ts)
- [ ] Add new message types: `requestConfirmation`, `confirmCommand`, `cancelCommand`
- [ ] Add `PendingCommandData` interface
- [ ] Update `IncomingMessage` type union

### 2. Add Confirmation Modal HTML/CSS (chatPanel.ts - _getHtmlForWebview)
- [ ] Add modal overlay HTML structure
- [ ] Add modal styling with CSS (dark theme matching existing design)
- [ ] Add "Onayla" and "İptal" buttons
- [ ] Add command preview display

### 3. Update Webview JavaScript
- [ ] Add state for pending command
- [ ] Add show/hide modal functions
- [ ] Add confirmation button handlers
- [ ] Update runTerminalCommand to show modal instead of executing directly

### 4. Update TypeScript Handler
- [ ] Handle `confirmCommand` - execute the pending command
- [ ] Handle `cancelCommand` - discard pending command and notify user

## Technical Details

### New Message Types:
```typescript
interface RequestConfirmationData {
    type: 'requestConfirmation';
    command: string;
    action: string;
}

interface ConfirmCommandData {
    type: 'confirmCommand';
    command: string;
}

interface CancelCommandData {
    type: 'cancelCommand';
    command: string;
}
```

### Modal UI:
- Dark themed modal with warning styling
- Shows the command that will be executed
- "Onayla" button (green/accent color)
- "İptal" button (red/gray color)
- Command execution only happens after confirmation

